This directory is used for emscripten builds.

Place all game files, excluding the .exe in this directory.
